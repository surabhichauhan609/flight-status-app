/**
 * v0 by Vercel.
 * @see https://v0.dev/t/ghge7ntF3vo
 * Documentation: https://v0.dev/docs#integrating-generated-code-into-your-nextjs-app
 */
import Link from "next/link"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar"
import { Card, CardContent } from "@/components/ui/card"

export default function Component() {
  return (
    <div className="flex flex-col min-h-screen">
      <header className="bg-background border-b px-4 md:px-6 flex items-center justify-between h-16 shrink-0">
        <div className="flex items-center gap-4">
          <Link href="#" className="flex items-center gap-2" prefetch={false}>
            <PlaneIcon className="w-6 h-6" />
            <span className="text-lg font-bold">FlightTracker</span>
          </Link>
          <form className="relative max-w-md w-full">
            <SearchIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Search flights"
              className="pl-10 pr-4 py-2 rounded-md w-full focus:ring-2 focus:ring-primary focus:outline-none"
            />
          
          </form>
          <h2 className="text-xl font-bold mb-2 ">Surabhi Chauhan</h2>

        </div>
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" className="rounded-full">
            <BellIcon className="w-6 h-6" />
            <span className="sr-only">Notifications</span>
          </Button>
          <Avatar className="w-8 h-8 border">
            <AvatarImage src="/placeholder-user.jpg" />
            <AvatarFallback>JD</AvatarFallback>
          </Avatar>
        </div>
      </header>
      <main className="flex-1 grid grid-cols-1 md:grid-cols-[1fr_300px] gap-8 p-4 md:p-8">
        <section>
          <div className="bg-background rounded-lg border p-4 md:p-6">
            <h2 className="text-xl font-bold mb-4">Upcoming Flights</h2>
            <div className="grid gap-4">
              <Card>
                <CardContent className="grid grid-cols-[1fr_auto] items-center gap-4">
                  <div className="flex flex-col gap-1">
                    <div className="flex items-center gap-2">
                      <div className="text-lg font-bold">Flight #AB123</div>
                      <div className="bg-green-500 px-2 py-1 rounded-md text-foreground text-xs font-medium">
                        On Time
                      </div>
                    </div>
                    <div className="flex justify-between">
                      <div className="flex flex-col gap-1">
                        <div className="text-sm text-muted-foreground">Departure</div>
                        <div className="flex items-center gap-2">
                          <div className="text-2xl font-medium">SFO</div>
                        </div>
                        <div>10:30 AM</div>
                      </div>
                      <div className="flex flex-col gap-1">
                        <div className="text-sm text-muted-foreground">Arrival</div>
                        <div className="flex items-center gap-2">
                          <div className="text-2xl font-medium">JFK</div>
                        </div>
                        <div>5:45 PM</div>
                      </div>
                    </div>
                  </div>
                  <div className="flex flex-col items-end gap-2">
                    <div className="text-sm text-muted-foreground">Duration: 7h 15m</div>
                    <Button variant="outline" size="sm">
                      View Details
                    </Button>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="grid grid-cols-[1fr_auto] items-center gap-4">
                  <div className="flex flex-col gap-1">
                    <div className="flex items-center gap-2">
                      <div className="text-lg font-bold">Flight #CD456</div>
                      <div className="bg-yellow-500 px-2 py-1 rounded-md text-foreground text-xs font-medium">
                        Delayed
                      </div>
                    </div>
                    <div className="flex justify-between">
                      <div className="flex flex-col gap-1">
                        <div className="text-sm text-muted-foreground">Departure</div>
                        <div className="flex items-center gap-2">
                          <div className="text-2xl font-medium">LAX</div>
                        </div>
                        <div>11:00 AM</div>
                      </div>
                      <div className="flex flex-col gap-1">
                        <div className="text-sm text-muted-foreground">Arrival</div>
                        <div className="flex items-center gap-2">
                          <div className="text-2xl font-medium">ORD</div>
                        </div>
                        <div>6:30 PM</div>
                      </div>
                    </div>
                  </div>
                  <div className="flex flex-col items-end gap-2">
                    <div className="text-sm text-muted-foreground">Duration: 7h 30m</div>
                    <Button variant="outline" size="sm">
                      View Details
                    </Button>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="grid grid-cols-[1fr_auto] items-center gap-4">
                  <div className="flex flex-col gap-1">
                    <div className="flex items-center gap-2">
                      <div className="text-lg font-bold">Flight #EF789</div>
                      <div className="bg-red-500 px-2 py-1 rounded-md text-foreground text-xs font-medium">
                        Canceled
                      </div>
                    </div>
                    <div className="flex justify-between">
                      <div className="flex flex-col gap-1">
                        <div className="text-sm text-muted-foreground">Departure</div>
                        <div className="flex items-center gap-2">
                          <div className="text-2xl font-medium">ORD</div>
                        </div>
                        <div>3:00 PM</div>
                      </div>
                      <div className="flex flex-col gap-1">
                        <div className="text-sm text-muted-foreground">Arrival</div>
                        <div className="flex items-center gap-2">
                          <div className="text-2xl font-medium">LGA</div>
                        </div>
                        <div>7:00 PM</div>
                      </div>
                    </div>
                  </div>
                  <div className="flex flex-col items-end gap-2">
                    <div className="text-sm text-muted-foreground">Duration: 4h 0m</div>
                    <Button variant="outline" size="sm">
                      View Details
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>
        <section>
          <div className="bg-background rounded-lg border p-4 md:p-6">
            <h2 className="text-xl font-bold mb-4">Notifications</h2>
            <div className="grid gap-4">
              <div className="flex items-start gap-4">
                <div className="bg-blue-500 rounded-full w-8 h-8 flex items-center justify-center">
                  <BellIcon className="w-5 h-5 text-foreground" />
                </div>
                <div className="flex-1">
                  <div className="text-sm font-medium">Your flight has been confirmed</div>
                  <div className="text-sm text-muted-foreground">5 minutes ago</div>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <div className="bg-blue-500 rounded-full w-8 h-8 flex items-center justify-center">
                  <CircleAlertIcon className="w-5 h-5 text-foreground" />
                </div>
                <div className="flex-1">
                  <div className="text-sm font-medium">Your flight has been delayed</div>
                  <div className="text-sm text-muted-foreground">1 hour ago</div>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <div className="bg-blue-500 rounded-full w-8 h-8 flex items-center justify-center">
                  <CircleXIcon className="w-5 h-5 text-foreground" />
                </div>
                <div className="flex-1">
                  <div className="text-sm font-medium">Your flight has been canceled</div>
                  <div className="text-sm text-muted-foreground">2 hours ago</div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>
    </div>
  )
}

function BellIcon(props) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9" />
      <path d="M10.3 21a1.94 1.94 0 0 0 3.4 0" />
    </svg>
  )
}


function CircleAlertIcon(props) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <circle cx="12" cy="12" r="10" />
      <line x1="12" x2="12" y1="8" y2="12" />
      <line x1="12" x2="12.01" y1="16" y2="16" />
    </svg>
  )
}


function CircleXIcon(props) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <circle cx="12" cy="12" r="10" />
      <path d="m15 9-6 6" />
      <path d="m9 9 6 6" />
    </svg>
  )
}


function PlaneIcon(props) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M17.8 19.2 16 11l3.5-3.5C21 6 21.5 4 21 3c-1-.5-3 0-4.5 1.5L13 8 4.8 6.2c-.5-.1-.9.1-1.1.5l-.3.5c-.2.5-.1 1 .3 1.3L9 12l-2 3H4l-1 1 3 2 2 3 1-1v-3l3-2 3.5 5.3c.3.4.8.5 1.3.3l.5-.2c.4-.3.6-.7.5-1.2z" />
    </svg>
  )
}


function SearchIcon(props) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <circle cx="11" cy="11" r="8" />
      <path d="m21 21-4.3-4.3" />
    </svg>
  )
}


function XIcon(props) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M18 6 6 18" />
      <path d="m6 6 12 12" />
    </svg>
  )
}
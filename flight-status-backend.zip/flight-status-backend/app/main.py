from fastapi import FastAPI
from app.routes import flight_routes, notification_routes

app = FastAPI()

app.include_router(flight_routes.router, prefix="/flights", tags=["flights"])
app.include_router(notification_routes.router, prefix="/notifications", tags=["notifications"])

@app.get("/")
def read_root():
    return {"message": "Flight Status System API"}

from app.utils.kafka_producer import KafkaProducer

class NotificationService:
    @staticmethod
    def send_notification(message: str, notification_type: str):
        if notification_type == "sms":
            # Send SMS
            pass
        elif notification_type == "email":
            # Send Email
            pass
        elif notification_type == "app":
            # Send App Notification
            pass
        KafkaProducer.produce(message)

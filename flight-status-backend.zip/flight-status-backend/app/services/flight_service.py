import json

class FlightService:
    @staticmethod
    def get_flight_status(flight_id: str):
        with open('data/mock_airport_data.json') as f:
            data = json.load(f)
            return data.get(flight_id, None)

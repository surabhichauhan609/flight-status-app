from pydantic import BaseModel
from typing import Optional

class FlightStatus(BaseModel):
    flight_id: str
    status: str
    gate: Optional[str]
    departure: Optional[str]

class NotificationRequest(BaseModel):
    flight_id: str
    notification_type: str  # Can be 'sms', 'email', or 'app'
    contact: str            # Phone number, email address, or device ID

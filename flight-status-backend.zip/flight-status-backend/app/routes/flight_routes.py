from fastapi import APIRouter, HTTPException
from app.services.flight_service import FlightService
from app.schemas import FlightStatus

router = APIRouter()

@router.get("/{flight_id}", response_model=FlightStatus)
def get_flight_status(flight_id: str):
    """
    Get the current status of a flight by its ID.
    """
    status = FlightService.get_flight_status(flight_id)
    if not status:
        raise HTTPException(status_code=404, detail="Flight not found")
    return status

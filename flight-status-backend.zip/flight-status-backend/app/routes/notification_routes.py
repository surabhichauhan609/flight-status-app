from fastapi import APIRouter, HTTPException
from app.services.notification_service import NotificationService
from app.schemas import NotificationRequest

router = APIRouter()

@router.post("/subscribe")
def subscribe_to_notifications(request: NotificationRequest):
    """
    Subscribe to notifications for a flight status change.
    """
    try:
        NotificationService.subscribe(request)
        return {"message": "Subscription successful"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/unsubscribe")
def unsubscribe_from_notifications(request: NotificationRequest):
    """
    Unsubscribe from notifications for a flight status change.
    """
    try:
        NotificationService.unsubscribe(request)
        return {"message": "Unsubscription successful"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

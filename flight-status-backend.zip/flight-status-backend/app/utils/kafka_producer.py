from kafka import KafkaProducer

class KafkaProducer:
    producer = KafkaProducer(bootstrap_servers='localhost:9092')

    @staticmethod
    def produce(message: str):
        KafkaProducer.producer.send('flight_updates', message.encode('utf-8'))
